// controllers/adminController.js
const pool = require('../db');

// 1. Dashboard stats
const getDashboardStats = async (req, res) => {
    try {
        const userResult = await pool.query(`
            SELECT 
                COUNT(*) as total_users,
                COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as new_users_week
            FROM users
        `);

        const reviewResult = await pool.query(`
            SELECT 
                COUNT(*) as total_reviews,
                COUNT(CASE WHEN dislikes >= 5 THEN 1 END) as flagged_reviews,
                COALESCE(SUM(dislikes),0) as total_dislikes,
                ROUND(COALESCE(AVG(rating),0),1) as avg_rating
            FROM reviews
        `);

        const today = new Date().toISOString().split('T')[0];
        const reservationResult = await pool.query(`
            SELECT 
                COUNT(*) as total_reservations,
                COUNT(CASE WHEN res_date = $1 THEN 1 END) as today_reservations
            FROM reservations
        `, [today]);

        res.json({
            success: true,
            stats: {
                users: userResult.rows[0],
                reviews: reviewResult.rows[0],
                reservations: reservationResult.rows[0]
            }
        });
    } catch (err) {
        console.error('Dashboard stats error:', err);
        res.status(500).json({ success: false, message: 'Server error fetching stats', error: err.message });
    }
};

// 2. Flagged reviews
const getFlaggedReviews = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT r.id, r.rating, r.comment, r.likes, r.dislikes, r.created_at,
                   u.name as user_name, u.email as user_email
            FROM reviews r
            LEFT JOIN users u ON r.user_id = u.id
            WHERE r.dislikes >= 5
            ORDER BY r.dislikes DESC, r.created_at DESC
            LIMIT 20
        `);

        res.json({ success: true, reviews: result.rows });
    } catch (err) {
        console.error('Flagged reviews error:', err);
        res.status(500).json({ success: false, message: 'Server error fetching flagged reviews', error: err.message });
    }
};

// 3. Recent reservations
const getRecentReservations = async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const result = await pool.query(`
            SELECT r.id, r.name, r.email, r.res_date, r.res_time, r.people, r.created_at,
                   u.email as user_email
            FROM reservations r
            LEFT JOIN users u ON r.user_id = u.id
            ORDER BY r.created_at DESC
            LIMIT $1
        `, [limit]);

        res.json({ success: true, reservations: result.rows });
    } catch (err) {
        console.error('Recent reservations error:', err);
        res.status(500).json({ success: false, message: 'Server error fetching reservations', error: err.message });
    }
};

// 4. Recent users
const getRecentUsers = async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const result = await pool.query(`
            SELECT u.id, u.name, u.email, u.created_at,
                   COALESCE((SELECT COUNT(*) FROM reviews WHERE user_id = u.id), 0) as review_count,
                   COALESCE((SELECT COUNT(*) FROM reservations WHERE user_id = u.id), 0) as reservation_count
            FROM users u
            ORDER BY u.created_at DESC
            LIMIT $1
        `, [limit]);

        res.json({ success: true, users: result.rows });
    } catch (err) {
        console.error('Recent users error:', err);
        res.status(500).json({ success: false, message: 'Server error fetching users', error: err.message });
    }
};

// 5. Admin logs
const getAdminLogs = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT al.*, u.name as admin_name, u.email as admin_email
            FROM admin_logs al
            LEFT JOIN users u ON al.admin_id = u.id
            ORDER BY al.created_at DESC
            LIMIT 10
        `);

        res.json({ success: true, logs: result.rows });
    } catch (err) {
        console.error('Admin logs error:', err);
        res.json({ success: true, logs: [], message: 'Logs table not available' });
    }
};

// 6. Review action (approve/delete)
const reviewAction = async (req, res) => {
    try {
        const { id } = req.params;
        const { action } = req.body;
        const adminId = req.user.id;

        if (!['approve', 'delete'].includes(action)) {
            return res.status(400).json({ success: false, message: 'Invalid action. Use "approve" or "delete"' });
        }

        if (action === 'delete') {
            const result = await pool.query('DELETE FROM reviews WHERE id = $1 RETURNING *', [id]);
            if (result.rows.length === 0) return res.status(404).json({ success: false, message: 'Review not found' });
            res.json({ success: true, message: 'Review deleted successfully', data: result.rows[0] });
        } else {
            const result = await pool.query('UPDATE reviews SET dislikes = 0 WHERE id = $1 RETURNING *', [id]);
            if (result.rows.length === 0) return res.status(404).json({ success: false, message: 'Review not found' });
            res.json({ success: true, message: 'Review approved successfully', data: result.rows[0] });
        }

    } catch (err) {
        console.error('Review action error:', err);
        res.status(500).json({ success: false, message: 'Server error processing review action', error: err.message });
    }
};

// 7. Test endpoint
const testAdminAPI = async (req, res) => {
    res.json({
        success: true,
        message: 'Admin API is working!',
        timestamp: new Date().toISOString(),
        endpoints: [
            '/dashboard/stats',
            '/reviews/flagged',
            '/reservations',
            '/users',
            '/logs'
        ]
    });
};

module.exports = {
    getDashboardStats,
    getFlaggedReviews,
    getRecentReservations,
    getRecentUsers,
    getAdminLogs,
    reviewAction,
    testAdminAPI
};
