// controllers/reactionController.js
const pool = require('../db');

// POST /api/reviews/:id/react - Like/Dislike a review
const reactToReview = async (req, res) => {
    try {
        const reviewId = parseInt(req.params.id);
        const { type, previous } = req.body; // type: "like", "dislike", "remove"

        // 1. Check if review exists
        const reviewCheck = await pool.query(
            'SELECT id, likes, dislikes FROM reviews WHERE id = $1',
            [reviewId]
        );

        if (reviewCheck.rows.length === 0) {
            return res.status(404).json({ message: "Review not found" });
        }

        let currentLikes = parseInt(reviewCheck.rows[0].likes) || 0;
        let currentDislikes = parseInt(reviewCheck.rows[0].dislikes) || 0;

        // 2. Update counts based on reaction type
        if (type === "remove") {
            if (previous === "like" && currentLikes > 0) currentLikes -= 1;
            else if (previous === "dislike" && currentDislikes > 0) currentDislikes -= 1;

        } else if (type === "like") {
            currentLikes += 1;
            if (previous === "dislike" && currentDislikes > 0) currentDislikes -= 1;

        } else if (type === "dislike") {
            currentDislikes += 1;
            if (previous === "like" && currentLikes > 0) currentLikes -= 1;

        } else {
            return res.status(400).json({ message: "Invalid reaction type" });
        }

        // Ensure counts don't go negative
        currentLikes = Math.max(0, currentLikes);
        currentDislikes = Math.max(0, currentDislikes);

        // 3. Update database
        await pool.query(
            'UPDATE reviews SET likes = $1, dislikes = $2 WHERE id = $3',
            [currentLikes, currentDislikes, reviewId]
        );

        // 4. Send response
        res.json({
            likes: currentLikes,
            dislikes: currentDislikes,
            message: "Reaction updated successfully"
        });

    } catch (error) {
        console.error("Error in reaction endpoint:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// GET /api/reviews/:id/counts - Get like/dislike counts
const getReactionCounts = async (req, res) => {
    try {
        const reviewId = parseInt(req.params.id);

        const result = await pool.query(
            'SELECT likes, dislikes FROM reviews WHERE id = $1',
            [reviewId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Review not found" });
        }

        res.json({
            likes: parseInt(result.rows[0].likes) || 0,
            dislikes: parseInt(result.rows[0].dislikes) || 0
        });

    } catch (error) {
        console.error("Error getting counts:", error);
        res.status(500).json({ message: "Server error" });
    }
};

module.exports = { reactToReview, getReactionCounts };
