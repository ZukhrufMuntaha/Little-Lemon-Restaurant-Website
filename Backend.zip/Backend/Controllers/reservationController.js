// controllers/reservationController.js
const pool = require('../db');

// Get all reservations (admin view)
const getAllReservations = async (req, res) => {
    try {
        const reservations = await pool.query(
            `SELECT res.id, res.name, res.email, res.res_date, res.res_time, res.people, u.email AS user_email
             FROM reservations res
             JOIN users u ON res.user_id = u.id
             ORDER BY res.res_date DESC`
        );
        res.json(reservations.rows);
    } catch (err) {
        console.error("Error fetching reservations:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

// Make a reservation
const createReservation = async (req, res) => {
    const { name, email, res_date, res_time, people } = req.body;

    if (!name || !email || !res_date || !res_time || !people)
        return res.status(400).json({ message: "All fields are required" });

    try {
        const result = await pool.query(
            `INSERT INTO reservations (user_id, name, email, res_date, res_time, people)
             VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
            [req.user.id, name, email, res_date, res_time, people]
        );
        res.json({ message: "Booking successful", reservation: result.rows[0] });
    } catch (err) {
        console.error("Error creating reservation:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

module.exports = { getAllReservations, createReservation };
