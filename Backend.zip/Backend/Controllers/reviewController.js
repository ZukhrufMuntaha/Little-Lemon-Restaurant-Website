// controllers/reviewController.js
const pool = require('../db');

// Get all reviews
const getAllReviews = async (req, res) => {
    try {
        const reviews = await pool.query(`
            SELECT r.id, r.rating, r.comment, r.created_at, r.likes, r.dislikes,
                   u.email AS user_email,
                   r.needs_review,
                   r.admin_notes
            FROM reviews r
            LEFT JOIN users u ON r.user_id = u.id
            ORDER BY r.created_at DESC
        `);
        res.json(reviews.rows);
    } catch (err) {
        console.error('Error fetching reviews:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get flagged reviews
const getFlaggedReviews = async (req, res) => {
    try {
        const flaggedReviews = await pool.query(`
            SELECT r.*, 
                   u.email as user_email,
                   u.name as user_name,
                   (r.likes + r.dislikes) as total_reactions,
                   CASE 
                       WHEN r.dislikes >= 10 THEN 'critical'
                       WHEN r.dislikes >= 5 THEN 'warning'
                       ELSE 'normal'
                   END AS flag_level
            FROM reviews r
            LEFT JOIN users u ON r.user_id = u.id
            WHERE r.dislikes >= 5 OR r.needs_review = true
            ORDER BY r.dislikes DESC, r.created_at DESC
        `);
        res.json(flaggedReviews.rows);
    } catch (err) {
        console.error('Error fetching flagged reviews:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get review stats
const getReviewStats = async (req, res) => {
    try {
        const stats = await pool.query(`
            SELECT 
                COUNT(*) as total_reviews,
                COALESCE(SUM(likes), 0) as total_likes,
                COALESCE(SUM(dislikes), 0) as total_dislikes,
                COUNT(CASE WHEN dislikes >= 5 THEN 1 END) as flagged_reviews
            FROM reviews
        `);
        res.json(stats.rows[0]);
    } catch (err) {
        console.error('Error fetching stats:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Mark review as reviewed
const markReviewReviewed = async (req, res) => {
    try {
        const { id } = req.params;
        await pool.query('UPDATE reviews SET needs_review = false WHERE id = $1', [id]);
        res.json({ message: 'Review marked as reviewed', reviewId: id });
    } catch (err) {
        console.error('Error marking review:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Delete a review (admin)
const deleteReview = async (req, res) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;

        const review = await pool.query('SELECT user_id, comment FROM reviews WHERE id = $1', [id]);
        if (review.rows.length === 0) return res.status(404).json({ message: 'Review not found' });

        await pool.query('DELETE FROM reviews WHERE id = $1', [id]);
        await pool.query('DELETE FROM review_reactions WHERE review_id = $1', [id]);
        await pool.query(
            'INSERT INTO admin_logs (admin_id, action, target_id, details) VALUES ($1, $2, $3, $4)',
            [req.user.id, 'review_deleted', id, `Review ${id} deleted. Reason: ${reason}. Content: ${review.rows[0].comment.substring(0, 100)}`]
        );

        res.json({ message: 'Review deleted successfully', reviewId: id });
    } catch (err) {
        console.error('Error deleting review:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get single review details for admin
const getReviewDetails = async (req, res) => {
    try {
        const { id } = req.params;
        const review = await pool.query(`
            SELECT r.*, 
                   u.email as user_email,
                   u.created_at as user_joined,
                   COUNT(DISTINCT rr_like.id) as total_likes_reactions,
                   COUNT(DISTINCT rr_dislike.id) as total_dislikes_reactions
            FROM reviews r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN review_reactions rr_like ON r.id = rr_like.review_id AND rr_like.type = 'like'
            LEFT JOIN review_reactions rr_dislike ON r.id = rr_dislike.review_id AND rr_dislike.type = 'dislike'
            WHERE r.id = $1
            GROUP BY r.id, u.email, u.created_at
        `, [id]);

        if (review.rows.length === 0) return res.status(404).json({ message: 'Review not found' });

        res.json(review.rows[0]);
    } catch (err) {
        console.error('Error fetching review details:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Post a new review
const postReview = async (req, res) => {
    const { rating, comment } = req.body;
    if (!rating || !comment) return res.status(400).json({ message: "Rating and comment are required" });

    try {
        const result = await pool.query(
            `INSERT INTO reviews (user_id, rating, comment) VALUES ($1, $2, $3) RETURNING *`,
            [req.user.id, rating, comment]
        );

        const userResult = await pool.query('SELECT email FROM users WHERE id = $1', [req.user.id]);

        const review = {
            ...result.rows[0],
            user_email: userResult.rows[0]?.email || 'Unknown',
            likes: 0,
            dislikes: 0
        };

        res.json({ message: "Review posted successfully", review });
    } catch (err) {
        console.error('Error posting review:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Like/Dislike a review (auto-flag)
const reactToReview = async (req, res) => {
    try {
        const reviewId = parseInt(req.params.id);
        const { type, previous } = req.body;

        const reviewCheck = await pool.query('SELECT id, likes, dislikes, needs_review FROM reviews WHERE id = $1', [reviewId]);
        if (reviewCheck.rows.length === 0) return res.status(404).json({ message: "Review not found" });

        let currentLikes = parseInt(reviewCheck.rows[0].likes) || 0;
        let currentDislikes = parseInt(reviewCheck.rows[0].dislikes) || 0;
        let needsReview = reviewCheck.rows[0].needs_review;

        if (type === "remove") {
            if (previous === "like" && currentLikes > 0) currentLikes -= 1;
            else if (previous === "dislike" && currentDislikes > 0) currentDislikes -= 1;
        } else if (type === "like") {
            currentLikes += 1;
            if (previous === "dislike" && currentDislikes > 0) currentDislikes -= 1;
        } else if (type === "dislike") {
            currentDislikes += 1;
            if (previous === "like" && currentLikes > 0) currentLikes -= 1;
        } else {
            return res.status(400).json({ message: "Invalid reaction type" });
        }

        // Auto-flag
        if (currentDislikes >= 5) needsReview = true;

        currentLikes = Math.max(0, currentLikes);
        currentDislikes = Math.max(0, currentDislikes);

        await pool.query(
            'UPDATE reviews SET likes = $1, dislikes = $2, needs_review = $3 WHERE id = $4',
            [currentLikes, currentDislikes, needsReview, reviewId]
        );

        res.json({ likes: currentLikes, dislikes: currentDislikes, needs_review: needsReview, message: "Reaction updated successfully" });
    } catch (err) {
        console.error("Error in react endpoint:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
};

module.exports = {
    getAllReviews,
    getFlaggedReviews,
    getReviewStats,
    markReviewReviewed,
    deleteReview,
    getReviewDetails,
    postReview,
    reactToReview
};
