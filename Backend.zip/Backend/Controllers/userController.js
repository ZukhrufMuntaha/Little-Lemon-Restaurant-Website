// controllers/userController.js
const pool = require('../db');

// Get all users (admin only)
const getAllUsers = async (req, res) => {
    try {
        const users = await pool.query(`
            SELECT id, email, created_at, 
                   (SELECT COUNT(*) FROM reviews WHERE user_id = users.id) as review_count,
                   (SELECT COUNT(*) FROM review_reactions WHERE user_id = users.id) as reaction_count
            FROM users
            ORDER BY created_at DESC
        `);
        res.json(users.rows);
    } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user count for dashboard
const getUserCount = async (req, res) => {
    try {
        const result = await pool.query('SELECT COUNT(*) as count FROM users');
        res.json({ count: parseInt(result.rows[0].count) });
    } catch (err) {
        console.error('Error counting users:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user statistics
const getUserStats = async (req, res) => {
    try {
        const stats = await pool.query(`
            SELECT 
                COUNT(*) as total_users,
                COUNT(CASE WHEN created_at >= NOW() - INTERVAL '7 days' THEN 1 END) as new_users_week,
                COUNT(CASE WHEN created_at >= NOW() - INTERVAL '30 days' THEN 1 END) as new_users_month,
                (SELECT COUNT(*) FROM users WHERE email LIKE '%@admin%') as admin_users,
                (SELECT COUNT(*) FROM users WHERE email LIKE '%@gmail.com%') as gmail_users
            FROM users
        `);
        res.json(stats.rows[0]);
    } catch (err) {
        console.error('Error fetching user stats:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user details with recent reviews
const getUserDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const user = await pool.query(`
            SELECT u.*, 
                   COUNT(r.id) as total_reviews,
                   AVG(r.rating) as avg_rating,
                   SUM(r.likes) as total_likes_received,
                   SUM(r.dislikes) as total_dislikes_received,
                   COUNT(CASE WHEN r.needs_review = TRUE THEN 1 END) as flagged_reviews
            FROM users u
            LEFT JOIN reviews r ON u.id = r.user_id
            WHERE u.id = $1
            GROUP BY u.id
        `, [id]);

        if (user.rows.length === 0) return res.status(404).json({ message: 'User not found' });

        const reviews = await pool.query(`
            SELECT * FROM reviews 
            WHERE user_id = $1 
            ORDER BY created_at DESC 
            LIMIT 10
        `, [id]);

        res.json({ user: user.rows[0], recent_reviews: reviews.rows });
    } catch (err) {
        console.error('Error fetching user details:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

module.exports = {
    getAllUsers,
    getUserCount,
    getUserStats,
    getUserDetails
};
