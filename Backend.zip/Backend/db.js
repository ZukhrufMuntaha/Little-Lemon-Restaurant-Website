require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT,
    max: 20, // Max 20 users db ma connect kr sktay hy
    idleTimeoutMillis: 30000,  //30 seconds idle rahnay wala connection close hojai ga
    connectionTimeoutMillis: 2000,  //agr 2 secs ma connect na ho to error
});

pool.connect()
    .then(client => {
        console.log(`PostgreSQL connected successfully at ${new Date().toLocaleString()}`);
        client.release();
    })
    .catch(err => console.error('PostgreSQL connection error:', err));

    async function testDB() {
        const client = await pool.connect();
        try {
            console.log('Testing database connection...');
            
            const usersResult = await client.query('SELECT COUNT(*) FROM users');
            console.log(`Users: ${usersResult.rows[0].count}`);
            
            const reviewsResult = await client.query('SELECT COUNT(*) FROM reviews');
            console.log(`Reviews: ${reviewsResult.rows[0].count}`);
            
            const resResult = await client.query('SELECT COUNT(*) FROM reservations');
            console.log(`Reservations: ${resResult.rows[0].count}`);
            
            console.log('✅ Database connection successful!');
        } catch (error) {
            console.error('❌ Database error:', error.message);
        } finally {
            client.release(); // IMPORTANT: Release client back to pool
        }
    }
    
    testDB();
    
// Test connection
pool.on('connect', () => {
    console.log('PostgreSQL connected at', new Date().toLocaleString());
});

pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

// Export the pool - DON'T call pool.end() anywhere
module.exports = pool;

