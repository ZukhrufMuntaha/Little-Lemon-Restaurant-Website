require('dotenv').config();

//important packages
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const reviewRoutes = require('./routes/review');
const userRoutes = require('./routes/users');
const reservationRoutes = require('./routes/reservation');
const reactionRoutes = require('./routes/reactions');
const adminRoutes = require('./routes/admin');


//Express ka main server object bnta hy
const app = express();

// SIMPLE CORS CONFIGURATION - Remove complex options
app.use(cors()); // Default CORS settings

// Or minimal CORS:
// app.use(cors({
//     origin: true, // Allow all origins
//     credentials: true
// }));

app.use(bodyParser.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/users', userRoutes);
app.use('/api/reservations', reservationRoutes);
app.use('/api/reviews', reactionRoutes);
app.use('/api/admin', adminRoutes);

app.use(express.static("Pages"));

// Test routes
app.get('/', (req, res) => {
    res.json({ 
        message: 'Little Lemon Restaurant API',
        status: 'running',
        timestamp: new Date().toISOString()
    });
});

app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'API is working!',
        timestamp: new Date().toISOString()
    });
});

app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK',
        server: 'Running',
        timestamp: new Date().toISOString()
    });
});

// Admin debug route (no auth for testing)
app.get('/api/admin/debug', (req, res) => {
    res.json({
        success: true,
        message: 'Admin debug endpoint - No auth required',
        timestamp: new Date().toISOString(),
        note: 'This endpoint is for testing only'
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`✅ Server running on port ${PORT}`);
    console.log(`\n📡 Test these URLs in browser:`);
    console.log(`   http://localhost:${PORT}/api/health`);
    console.log(`   http://localhost:${PORT}/api/admin/debug`);
    console.log(`   http://localhost:${PORT}/api/admin/test`);
    console.log(`\n🛠️  For admin dashboard: http://localhost:5500/admin.html`);
});