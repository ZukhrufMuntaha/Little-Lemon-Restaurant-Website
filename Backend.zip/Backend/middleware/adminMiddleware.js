// middleware/adminMiddleware.js
const jwt = require('jsonwebtoken');
const pool = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-for-development-only';

async function authorizeAdmin(req, res, next) {
    try {
        // Get token from header
        const authHeader = req.headers['authorization'];
        if (!authHeader) {
            return res.status(401).json({ message: 'No authorization header' });
        }
        
        const token = authHeader.split(' ')[1];
        if (!token) {
            return res.status(401).json({ message: 'No token provided' });
        }

        // Verify token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Check if user is admin (for demo, check email)
        //token sa user id milti hy
        const userResult = await pool.query(
            'SELECT email FROM users WHERE id = $1',
            [decoded.id]
        );
        
        if (userResult.rows.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        const userEmail = userResult.rows[0].email;
        
        // For demo: If email is admin@gmail.com or contains 'admin'
        if (!userEmail.includes('admin') && userEmail !== 'admin@gmail.com') {
            return res.status(403).json({ 
                message: 'Admin access required',
                hint: 'Use admin@gmail.com to access admin panel'
            });
        }
        
        req.user = decoded;
        next();
    } catch (error) {
        console.error('Admin auth error:', error);
        
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({ message: 'Invalid token' });
        }
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ message: 'Token expired' });
        }
        
        res.status(500).json({ message: 'Authentication error' });
    }
}

module.exports = authorizeAdmin;