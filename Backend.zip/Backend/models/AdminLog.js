const pool = require('../db');

class AdminLog {
  static async create({ admin_id, action, target_id, details, ip_address }) {
    const result = await pool.query(
      `INSERT INTO admin_logs (admin_id, action, target_id, details, ip_address) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [admin_id, action, target_id, details, ip_address]
    );
    return result.rows[0];
  }

  static async findAll(limit = 10) {
    const result = await pool.query(
      `SELECT al.*, u.name as admin_name, u.email as admin_email 
       FROM admin_logs al 
       LEFT JOIN users u ON al.admin_id = u.id 
       ORDER BY al.created_at DESC 
       LIMIT $1`,
      [limit]
    );
    return result.rows;
  }
}

module.exports = AdminLog;