const pool = require('../db');

class Reservation {
  static async create({ user_id, name, email, res_date, res_time, people }) {
    const result = await pool.query(
      `INSERT INTO reservations (user_id, name, email, res_date, res_time, people) 
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [user_id, name, email, res_date, res_time, people]
    );
    return result.rows[0];
  }

  static async findAll(limit = 10, offset = 0) {
    const result = await pool.query(
      `SELECT r.*, u.email as user_email 
       FROM reservations r 
       LEFT JOIN users u ON r.user_id = u.id 
       ORDER BY r.created_at DESC 
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    return result.rows;
  }

  static async count() {
    const result = await pool.query('SELECT COUNT(*) FROM reservations');
    return parseInt(result.rows[0].count);
  }

  static async getStats() {
    const today = new Date().toISOString().split('T')[0];
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_reservations,
        COUNT(CASE WHEN res_date = $1 THEN 1 END) as today_reservations,
        COUNT(CASE WHEN res_date >= $1 THEN 1 END) as upcoming_reservations
      FROM reservations
    `, [today]);
    return result.rows[0];
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM reservations WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async delete(id) {
    await pool.query('DELETE FROM reservations WHERE id = $1', [id]);
    return true;
  }
}

module.exports = Reservation;