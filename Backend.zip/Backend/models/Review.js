const pool = require('../db');

class Review {
  static async create({ user_id, rating, comment, likes = 0, dislikes = 0 }) {
    const result = await pool.query(
      'INSERT INTO reviews (user_id, rating, comment, likes, dislikes) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [user_id, rating, comment, likes, dislikes]
    );
    return result.rows[0];
  }

  static async findFlagged(limit = 20) {
    const result = await pool.query(
      `SELECT r.*, u.name as user_name, u.email as user_email 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       WHERE r.dislikes >= 5 
       ORDER BY r.dislikes DESC, r.created_at DESC 
       LIMIT $1`,
      [limit]
    );
    return result.rows;
  }

  static async findAll(limit = 10, offset = 0) {
    const result = await pool.query(
      'SELECT * FROM reviews ORDER BY created_at DESC LIMIT $1 OFFSET $2',
      [limit, offset]
    );
    return result.rows;
  }

  static async count() {
    const result = await pool.query('SELECT COUNT(*) FROM reviews');
    return parseInt(result.rows[0].count);
  }

  static async getStats() {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_reviews,
        COUNT(CASE WHEN dislikes >= 5 THEN 1 END) as flagged_reviews,
        COALESCE(SUM(dislikes), 0) as total_dislikes,
        COALESCE(AVG(rating), 0) as avg_rating
      FROM reviews
    `);
    return result.rows[0];
  }

  static async findById(id) {
    const result = await pool.query('SELECT * FROM reviews WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async update(id, updates) {
    const { rating, comment, likes, dislikes } = updates;
    const result = await pool.query(
      'UPDATE reviews SET rating = $1, comment = $2, likes = $3, dislikes = $4 WHERE id = $5 RETURNING *',
      [rating, comment, likes, dislikes, id]
    );
    return result.rows[0];
  }

  static async delete(id) {
    await pool.query('DELETE FROM reviews WHERE id = $1', [id]);
    return true;
  }
}

module.exports = Review;