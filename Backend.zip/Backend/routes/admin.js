// routes/admin.js
const express = require('express');
const router = express.Router();
const authenticateAdmin = require('../middleware/adminMiddleware'); // admin auth middleware
const adminController = require('../Controllers/adminController');

// Admin routes
router.get('/dashboard/stats', authenticateAdmin, adminController.getDashboardStats);
router.get('/reviews/flagged', authenticateAdmin, adminController.getFlaggedReviews);
router.get('/reservations', authenticateAdmin, adminController.getRecentReservations);
router.get('/users', authenticateAdmin, adminController.getRecentUsers);
router.get('/logs', authenticateAdmin, adminController.getAdminLogs);

// Review approve/delete action
router.post('/reviews/:id/action', authenticateAdmin, adminController.reviewAction);

// Test endpoint
router.get('/test', adminController.testAdminAPI);

module.exports = router;
