// routes/reactions.js
const express = require('express');
const router = express.Router();
const reactionController = require('../Controllers/reactionController');

// Routes
router.post('/:id/react', reactionController.reactToReview);
router.get('/:id/counts', reactionController.getReactionCounts);

module.exports = router;
