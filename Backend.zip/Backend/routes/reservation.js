// routes/reservation.js
const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authMiddleware');
const reservationController = require('../Controllers/reservationController');

// Routes
router.get('/', authenticateToken, reservationController.getAllReservations);
router.post('/', authenticateToken, reservationController.createReservation);

module.exports = router;
