// routes/reviews.js
const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authMiddleware');
const authorizeAdmin = require('../middleware/adminMiddleware');
const reviewController = require('../Controllers/reviewController');

// Public
router.get('/', reviewController.getAllReviews);
router.post('/', authenticateToken, reviewController.postReview);

// Admin routes
router.get('/flagged', authenticateToken, authorizeAdmin, reviewController.getFlaggedReviews);
router.get('/stats', authenticateToken, authorizeAdmin, reviewController.getReviewStats);
router.post('/:id/mark-reviewed', authenticateToken, authorizeAdmin, reviewController.markReviewReviewed);
router.delete('/:id', authenticateToken, authorizeAdmin, reviewController.deleteReview);
router.get('/:id/details', authenticateToken, authorizeAdmin, reviewController.getReviewDetails);

// Reactions
router.post('/:id/react', reviewController.reactToReview);

module.exports = router;
