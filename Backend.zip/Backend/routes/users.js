// routes/users.js
const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authMiddleware');
const authorizeAdmin = require('../middleware/adminMiddleware');
const userController = require('../Controllers/userController');

// Admin-only routes
router.get('/', authenticateToken, authorizeAdmin, userController.getAllUsers);
router.get('/count', authenticateToken, authorizeAdmin, userController.getUserCount);
router.get('/stats', authenticateToken, authorizeAdmin, userController.getUserStats);
router.get('/:id/details', authenticateToken, authorizeAdmin, userController.getUserDetails);

module.exports = router;
