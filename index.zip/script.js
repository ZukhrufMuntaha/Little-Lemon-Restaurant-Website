/*****************************
   Custom Validation Error
******************************/
class ValidationError extends Error {
    constructor(message, fieldId) {
        super(message);
        this.fieldId = fieldId;
    }
}

/*****************************
   Helper Validation Functions
******************************/
function validateGmail(value, fieldId) {
    if (!value.endsWith("@gmail.com")) {
        throw new ValidationError("Email must end with @gmail.com", fieldId);
    }
}

function validatePassword(value, fieldId) {
    if (value.length < 8) {
        throw new ValidationError("Password must be at least 8 characters", fieldId);
    }
}

function validateEmpty(value, fieldId, msg) {
    if (!value.trim()) {
        throw new ValidationError(msg, fieldId);
    }
}

/*****************************
   Clear All Errors
******************************/
function clearErrors(form) {
    form.querySelectorAll(".error").forEach(e => e.textContent = "");
    form.querySelectorAll("input, textarea").forEach(i => i.classList.remove("error-field"));
}

/*****************************
   Live Email Validation
******************************/
function liveEmailCheck(input, msgSpan) {
    input.addEventListener("input", () => {
        if (!input.value.endsWith("@gmail.com")) {
            msgSpan.textContent = "Email must end with @gmail.com";
            msgSpan.style.color = "red";
        } else {
            msgSpan.textContent = "Perfect ✔";
            msgSpan.style.color = "green";
        }
    });
}

/*****************************
   RESERVATION (LOGIN + SIGNUP FLOW + JWT + API)
******************************/

//Temporary
console.log("=== DEBUG RESERVATION ===");
console.log("resName exists:", document.getElementById("resName"));
console.log("resPeople exists:", document.getElementById("resPeople"));
console.log("resPeople value:", document.getElementById("resPeople")?.value);
console.log("Stored token:", localStorage.getItem("userToken"));
console.log("All localStorage:", { ...localStorage });

document.addEventListener("DOMContentLoaded", () => {
    if (!document.getElementById("reservationForm")) return; // safeguard

    const reservationForm = document.getElementById("reservationForm");
    const resFormMsg = document.getElementById("resFormMsg");
    const resName = document.getElementById("resName");
    const resEmail = document.getElementById("resEmail");
    const resDate = document.getElementById("resDate");
    const resTime = document.getElementById("resTime");
    const resPeople = document.getElementById("resPeople");
    const resMsg = document.getElementById("resMsg");

    // 🔹 Post reservation function
    async function postReservation() {
        const token = localStorage.getItem("userToken") || localStorage.getItem("token");
        console.log("Available tokens:", {
            userToken: localStorage.getItem("userToken"),
            token: localStorage.getItem("token")
        });
        
        if (!token) {
            localStorage.setItem("redirectAfterLogin", "reservation.html");
            window.location.href = "login.html";
            return;
        }
    
        const data = {
            name: resName.value.trim(),
            email: resEmail.value.trim(),
            res_date: resDate.value,
            res_time: resTime.value,
            people: parseInt(resPeople.value)
        };
    
        console.log("Sending reservation data:", data);
        console.log("Using token:", token);
    
        try {
            const response = await fetch("http://localhost:3000/api/reservations", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },
                body: JSON.stringify(data)
            });
    
            console.log("Response status:", response.status);
            const result = await response.json();
            console.log("Response data:", result);
            

            if (!response.ok) {
                if (response.status === 401 || result.message === "User not found") {
                    localStorage.setItem("redirectAfterSignup", "reservation.html");
                    window.location.href = "signup.html";
                    return;
                }
                if (resFormMsg) {
                    resFormMsg.textContent = result.message || "Booking failed";
                    resFormMsg.style.color = "red";
                }
                return;
            }

            if (resFormMsg) {
                resFormMsg.textContent = "Booking successful ✔";
                resFormMsg.style.color = "green";
            }
            reservationForm.reset();
            if (resMsg) resMsg.textContent = "";

        } catch (err) {
            console.error(err);
            if (resFormMsg) {
                resFormMsg.textContent = "Server error. Try again later.";
                resFormMsg.style.color = "red";
            }
        }
    }

    // 🔹 Book Now click
    reservationForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        document.querySelectorAll("#reservationForm .msg").forEach(span => span.textContent = "");
        if (resFormMsg) resFormMsg.textContent = "";

        try {
            if (resName.value.trim() === "") throw new ValidationError("Name is required", "resName");
            if (!resEmail.value.endsWith("@gmail.com")) throw new ValidationError("Email must end with @gmail.com", "resEmail");
            if (resDate.value === "") throw new ValidationError("Date is required", "resDate");
            if (resTime.value === "") throw new ValidationError("Time is required", "resTime");
            if (resPeople.value === "" || resPeople.value < 1) throw new ValidationError("Please enter number of people", "resPeople");

            const token = localStorage.getItem("userToken");
            console.log("Token used for reservation:", token);

            if (!token) {
                localStorage.setItem("redirectAfterLogin", "reservation.html");
                window.location.href = "login.html";
                return;
            }

            await postReservation();

        } catch (err) {
            if (err.fieldId) {
                const span = document.getElementById(err.fieldId + "Msg");
                if (span) {
                    span.textContent = err.message;
                    span.style.color = "red";
                    document.getElementById(err.fieldId)?.classList.add("error-field");
                }
            } else if (resFormMsg) {
                resFormMsg.textContent = "Server error. Try again later.";
                resFormMsg.style.color = "red";
                console.error(err);
            }
        }
    });

    // 🔹 Live email validation
    resEmail.addEventListener("input", () => {
        if (resMsg) {
            if (!resEmail.value.endsWith("@gmail.com")) {
                resMsg.textContent = "Email must end with @gmail.com";
                resMsg.style.color = "red";
            } else {
                resMsg.textContent = "Perfect ✔";
                resMsg.style.color = "green";
            }
        }
    });

    // 🔹 Auto post reservation if coming back from login/signup
    (async () => {
        const token = localStorage.getItem("userToken");
        const redirectPage = localStorage.getItem("redirectAfterLogin") || localStorage.getItem("redirectAfterSignup");
        if (token && redirectPage === "reservation.html") {
            localStorage.removeItem("redirectAfterLogin");
            localStorage.removeItem("redirectAfterSignup");
            await postReservation();
        }
    })();
});


/*****************************
   STAR RATING
******************************/
const stars = document.querySelectorAll(".stars-container .star");
let rating=0;

stars.forEach(s=>{
    s.textContent="☆";
    s.style.color="gray";
});

stars.forEach((star,i)=>{
    star.addEventListener("click",()=>{
        rating=i+1;
        stars.forEach((s,idx)=>{
            s.textContent=idx<rating?"★":"☆";
            s.style.color=idx<rating?"gold":"gray";
        });
        const reviewStarsMsg=document.getElementById("reviewStarsMsg");
        if(reviewStarsMsg) reviewStarsMsg.textContent="";
    });
});


/*****************************
   INIT LIKE/DISLIKE BUTTONS (FIXED)
******************************/
function initLikeDislike(container) {
    container.querySelectorAll(".review").forEach(review => {
        const reviewId = review.dataset.id;
        const likeBtn = review.querySelector(".like-btn");
        const dislikeBtn = review.querySelector(".dislike-btn");
        const likeCount = likeBtn.querySelector(".like-count");
        const dislikeCount = dislikeBtn.querySelector(".dislike-count");

        // Track user reaction locally
        let reaction = localStorage.getItem("review_" + reviewId) || null;

        async function updateCounts(type, previousReaction) {
            try {
                console.log(`Sending reaction: type=${type}, previous=${previousReaction}, reviewId=${reviewId}`);
                
                const res = await fetch(`http://localhost:3000/api/reviews/${reviewId}/react`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ 
                        type,
                        previous: previousReaction
                    })
                });
                
                console.log(`Response status: ${res.status}`);
                
                if (!res.ok) {
                    const errorText = await res.text();
                    console.error(`Server error: ${errorText}`);
                    throw new Error(`Failed to update: ${res.status}`);
                }
                
                const result = await res.json();
                console.log(`Server response:`, result);
                
                // Update display
                likeCount.textContent = result.likes || 0;
                dislikeCount.textContent = result.dislikes || 0;
        
                // Admin alert
                if (result.dislikes > 5) {
                    console.warn(`⚠️ Admin Alert: Review ${reviewId} has ${result.dislikes} dislikes!`);
                }
                
                return result;
                
            } catch(err) {
                console.error("Update counts error:", err);
                alert("Failed to update reaction. Please try again.");
            }
        }

        function renderButtons() {
            likeBtn.classList.toggle("active", reaction === "like");
            dislikeBtn.classList.toggle("active", reaction === "dislike");
        }

        likeBtn.addEventListener("click", async () => {
            let type, newReaction;
            const previousReaction = reaction;
            
            if(reaction === "like") {
                // Removing like
                type = "remove";
                newReaction = null;
            } else {
                // Adding like (or switching from dislike)
                type = "like";
                newReaction = "like";
            }
            
            // Update immediately for better UX
            reaction = newReaction;
            localStorage.setItem("review_" + reviewId, newReaction);
            renderButtons();
            
            // Then update server
            await updateCounts(type, previousReaction);
        });

        dislikeBtn.addEventListener("click", async () => {
            let type, newReaction;
            const previousReaction = reaction;
            
            if(reaction === "dislike") {
                // Removing dislike
                type = "remove";
                newReaction = null;
            } else {
                // Adding dislike (or switching from like)
                type = "dislike";
                newReaction = "dislike";
            }
            
            // Update immediately for better UX
            reaction = newReaction;
            localStorage.setItem("review_" + reviewId, newReaction);
            renderButtons();
            
            // Then update server
            await updateCounts(type, previousReaction);
        });

        renderButtons();
    });
}

/*****************************
   LOAD REVIEWS FUNCTION (Moved outside)
******************************/
async function loadReviews() {
    try {
        const response = await fetch('http://localhost:3000/api/reviews');
        const reviews = await response.json();
        
        const container = document.querySelector('.reviews-container');
        container.innerHTML = '';
        
        reviews.forEach(review => {
            const div = document.createElement("div");
            div.className = "review";
            div.dataset.id = review.id;
            div.innerHTML = `
                <h3>${review.user_email}</h3> <!-- Changed from user_name to user_email -->
                <p class="stars">${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}</p>
                <p>${review.comment}</p>
                <div class="review-actions">
                    <button class="like-btn">👍 <span class="like-count">${review.likes || 0}</span></button>
                    <button class="dislike-btn">👎 <span class="dislike-count">${review.dislikes || 0}</span></button>
                </div>
            `;
            container.appendChild(div);
        });
        
        // Initialize like/dislike buttons
        initLikeDislike(container);
        
    } catch (error) {
        console.error("Error loading reviews:", error);
    }
}

// Call on page load
document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector(".reviews-container")) {
        loadReviews();
    }
});

/*****************************
   REVIEW FORM LOGIC (FIXED)
******************************/
if (document.getElementById("reviewForm")) {
    const reviewForm = document.getElementById("reviewForm");
    const reviewText = document.getElementById("reviewText");
    const reviewMsg = document.getElementById("reviewFormMsg");
    const reviewContainer = document.querySelector(".reviews-container");
    const ratingStars = document.querySelectorAll(".stars-container .star");

    reviewForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        reviewMsg.textContent = "";

        const rating = Array.from(ratingStars).filter(s => s.textContent === "★").length;
        
        // Get token from localStorage (check both possible keys)
        const token = localStorage.getItem("userToken") || localStorage.getItem("token");
        console.log("Token for review:", token);
        
        // Get user email instead of name
        const userEmail = localStorage.getItem("userEmail");
        console.log("User email:", userEmail);

        // Check if user is logged in
        if (!token) {
            reviewMsg.textContent = "Please login to post a review.";
            reviewMsg.style.color = "red";
            
            // Add login button
            const loginBtn = document.createElement("button");
            loginBtn.textContent = "Go to Login";
            loginBtn.type = "button";
            loginBtn.style.marginLeft = "10px";
            loginBtn.addEventListener("click", () => window.location.href = "login.html");
            
            reviewMsg.appendChild(document.createElement("br"));
            reviewMsg.appendChild(loginBtn);
            return;
        }

        if (reviewText.value.trim() === "") {
            reviewMsg.textContent = "Review cannot be empty.";
            reviewMsg.style.color = "red";
            return;
        }
        
        if (rating === 0) {
            reviewMsg.textContent = "Please select a star rating.";
            reviewMsg.style.color = "red";
            return;
        }

        const data = { rating, comment: reviewText.value };

        try {
            console.log("Posting review with data:", data);
            console.log("Using token:", token);
            
            const response = await fetch("http://localhost:3000/api/reviews", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            console.log("Review post response:", result);

            if (!response.ok) {
                if (response.status === 401) {
                    reviewMsg.textContent = "Session expired. Please login again.";
                    reviewMsg.style.color = "red";
                    localStorage.removeItem("userToken");
                    localStorage.removeItem("token");
                } else {
                    reviewMsg.textContent = result.message || "Failed to post review.";
                    reviewMsg.style.color = "red";
                }
                return;
            }

            // Add review to page dynamically
            const div = document.createElement("div");
            div.className = "review";
            div.dataset.id = result.review.id;
            div.innerHTML = `
                <h3>${result.review.user_email || "User"}</h3>
                <p class="stars">${"★".repeat(rating)}${"☆".repeat(5 - rating)}</p>
                <p>${reviewText.value}</p>
                <div class="review-actions">
                    <button class="like-btn">👍 <span class="like-count">0</span></button>
                    <button class="dislike-btn">👎 <span class="dislike-count">0</span></button>
                </div>
            `;

            reviewContainer.prepend(div);

            reviewMsg.textContent = "Review posted successfully ✔";
            reviewMsg.style.color = "green";

            reviewForm.reset();
            ratingStars.forEach(s => { 
                s.textContent = "☆"; 
                s.style.color = "gray"; 
            });

            // Initialize like/dislike for this new review
            initLikeDislike(div);

        } catch (err) {
            console.error("Review post error:", err);
            reviewMsg.textContent = "Server error. Try again later.";
            reviewMsg.style.color = "red";
        }
    });
}

/*********************
       LOGIN
 *********************/
if (document.getElementById("loginForm")) {
    const loginForm = document.getElementById("loginForm");
    const loginEmail = document.getElementById("loginEmail");
    const loginPassword = document.getElementById("loginPassword");
    const loginFormMsg = document.getElementById("loginFormMsg");
    const loginEmailMsg = document.getElementById("loginMsg"); // HTML span id

    // Live email check
    liveEmailCheck(loginEmail, loginEmailMsg);

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        loginFormMsg.textContent = "";
        loginEmailMsg.textContent = "";

        try {
            // Email validation
            validateGmail(loginEmail.value, "loginEmail");

            const data = {
                email: loginEmail.value.trim(),
                password: loginPassword.value
            };

            console.log("Sending login data:", data);

            // Fetch request to backend
            const response = await fetch("http://localhost:3000/api/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            console.log("Server response:", result);

            if (!response.ok) {
                loginFormMsg.textContent = result.message;
                loginFormMsg.style.color = "red";

                // Redirect to signup page if user does not exist
                if (result.message === "User does not exist") {
                    setTimeout(() => {
                        window.location.href = "signup.html";
                    }, 1500);
                }

            } else {
    // ✅ SUCCESSFUL LOGIN
    localStorage.setItem("userLoggedIn", "true");
    
    //Stored in local storage
    if (result.token) {
        localStorage.setItem("userToken", result.token);
        localStorage.setItem("token", result.token);
        
        localStorage.setItem("userEmail", loginEmail.value.trim());
        console.log("User email stored:", loginEmail.value.trim());
    }
                loginFormMsg.textContent = result.message || "Login successful ✔";
                loginFormMsg.style.color = "green";

                // Reset form
                loginForm.reset();
                document.getElementById("loginPasswordMsg").textContent = "";
                loginEmailMsg.textContent = "";

                // Redirect to previous page if exists, else home
                const redirect = localStorage.getItem("redirectAfterLogin") || "index.html";
                localStorage.removeItem("redirectAfterLogin");
                window.location.href = redirect;

                if (result.token) {
                    localStorage.setItem("userToken", result.token);
                    localStorage.setItem("token", result.token);
                    localStorage.setItem("userEmail", loginEmail.value.trim()); // Store email
                    console.log("User email stored:", loginEmail.value.trim());
                }

                // login.js mein check karo - successful login ke baad:
 if (data.success) {
    localStorage.setItem('userToken', data.token);
    localStorage.setItem('userEmail', data.user.email);
    localStorage.setItem('userRole', data.user.role); 
    
    // Check if user is admin
    if (data.user.role === 'admin') {
        window.location.href = 'admin.html';
    } else {
        window.location.href = 'index.html';
    }
}

                setTimeout(() => {
                    window.location.href = redirect;
                }, 1500);
            }

        } catch (err) {
            if (err.fieldId === "loginEmail") {
                loginEmailMsg.textContent = err.message;
                loginEmailMsg.style.color = "red";
                loginEmail.classList.add("error-field");
            } else {
                loginFormMsg.textContent = "Server error. Try again later.";
                loginFormMsg.style.color = "red";
                console.error(err);
            }
        }
    });
}




/*****************************
   SIGNUP
******************************/
if (document.getElementById("signupForm")) {
    const signupForm = document.getElementById("signupForm");
    const signupName = document.getElementById("signupName");
    const signupEmail = document.getElementById("signupEmail");
    const signupPassword = document.getElementById("signupPassword");

    const signupNameMsg = document.getElementById("signupNameMsg");
    const signupEmailMsg = document.getElementById("signupMsg");
    const signupPasswordMsg = document.getElementById("signupPasswordMsg");
    const signupFormMsg = document.getElementById("signupFormMsg");

    // Live email check
    liveEmailCheck(signupEmail, signupEmailMsg);

    // Live password check
    signupPassword.addEventListener("input", () => {
        if (signupPassword.value.length < 8) {
            signupPasswordMsg.textContent = "Password must be at least 8 characters";
            signupPasswordMsg.style.color = "red";
        } else {
            signupPasswordMsg.textContent = "Strong password ✔";
            signupPasswordMsg.style.color = "green";
        }
    });

    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        clearErrors(signupForm);

        try {
            // Name validation
            if (signupName.value.trim().length < 3) {
                throw { fieldId: "signupName", message: "Name must have at least 3 characters" };
            }

            // Email & password validation
            validateGmail(signupEmail.value, "signupEmail");
            if (signupPassword.value.length < 8) {
                throw { fieldId: "signupPassword", message: "Password must be at least 8 characters" };
            }

            // Prepare data to send to backend
            const data = {
                name: signupName.value.trim(),
                email: signupEmail.value.trim(),
                password: signupPassword.value
            };

            console.log("Sending signup data:", data);

            // POST request to backend
            const response = await fetch("http://localhost:3000/api/auth/signup", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            console.log(result);

            if (!response.ok) {
                signupFormMsg.textContent = result.message;
                signupFormMsg.style.color = "red";
            } else {
                // Save token if backend returns one
                if (result.token) localStorage.setItem("userToken", result.token);

                signupFormMsg.textContent = result.message || "Account created successfully ✔";
                signupFormMsg.style.color = "green";

                // Reset form & inline messages
                signupForm.reset();
                signupNameMsg.textContent = "";
                signupEmailMsg.textContent = "";
                signupPasswordMsg.textContent = "";

                if (result.token) {
                    localStorage.setItem("userToken", result.token);
                    localStorage.setItem("userEmail", signupEmail.value.trim()); // Store email
                }

                // After successful signup
                const redirectSignup = localStorage.getItem("redirectAfterSignup") || "index.html";
                localStorage.removeItem("redirectAfterSignup");
                window.location.href = redirectSignup;

                // Redirect to home after 2 seconds
                setTimeout(() => {
                    window.location.href = "index.html";
                }, 2000);
            }

        } catch (err) {
            if (err.fieldId) {
                const msgSpan = document.getElementById(err.fieldId + "Msg");
                if (msgSpan) {
                    msgSpan.textContent = err.message;
                    msgSpan.style.color = "red";
                    document.getElementById(err.fieldId).classList.add("error-field");
                }
            } else {
                signupFormMsg.textContent = "Server error. Try again later.";
                signupFormMsg.style.color = "red";
                console.error(err);
            }
        }

    });
}
// script.js - Login/Logout Handler
document.addEventListener('DOMContentLoaded', function() {
    updateNavbar();
    setupLogout();
});

// Update navbar based on login status
function updateNavbar() {
    const token = localStorage.getItem('userToken');
    
    if (token) {
        // User logged in - show logout, hide login/signup
        document.getElementById('logout-link').style.display = 'block';
        document.getElementById('login-link').style.display = 'none';
        document.getElementById('signup-link').style.display = 'none';
    } else {
        // User not logged in - show login/signup, hide logout
        document.getElementById('logout-link').style.display = 'none';
        document.getElementById('login-link').style.display = 'block';
        document.getElementById('signup-link').style.display = 'block';
    }
}

// Setup logout button (no alert)
function setupLogout() {
    document.getElementById('logout-btn')?.addEventListener('click', function(e) {
        e.preventDefault();
        // Logout immediately without confirmation
        localStorage.removeItem('userToken');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userRole');
        window.location.href = 'index.html';
    });
}

// Login form handler (no alerts)
if (document.getElementById("loginForm")) {
    document.getElementById("loginForm").addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const email = document.getElementById("loginEmail").value.trim();
        const password = document.getElementById("loginPassword").value;
        const loginMsg = document.getElementById("loginFormMsg");
        
        try {
            const response = await fetch("http://localhost:3000/api/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });
            
            const result = await response.json();
            
            if (response.ok) {
                // Store user data
                localStorage.setItem("userToken", result.token);
                localStorage.setItem("userEmail", email);
                localStorage.setItem("userRole", result.user?.role || 'user');
                
                // Show success message
                if (loginMsg) {
                    loginMsg.textContent = "Login successful! Redirecting...";
                    loginMsg.style.color = "green";
                }
                
                // Redirect based on role
                setTimeout(() => {
                    if (result.user?.role === 'admin') {
                        window.location.href = 'admin.html';
                    } else {
                        const redirect = localStorage.getItem("redirectAfterLogin") || "index.html";
                        localStorage.removeItem("redirectAfterLogin");
                        window.location.href = redirect;
                    }
                }, 1000);
                
            } else {
                // Show error message
                if (loginMsg) {
                    loginMsg.textContent = result.message || "Login failed";
                    loginMsg.style.color = "red";
                }
            }
        } catch (error) {
            if (loginMsg) {
                loginMsg.textContent = "Server error. Try again.";
                loginMsg.style.color = "red";
            }
        }
    });
}

// Auto-check on page load
window.addEventListener('storage', updateNavbar);