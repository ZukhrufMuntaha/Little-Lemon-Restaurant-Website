const API_BASE_URL = 'http://localhost:3000'; // Domain only

// Track processed reviews
let processedReviews = {};
try {
    processedReviews = JSON.parse(localStorage.getItem('processedReviews') || '{}');
} catch (e) {
    console.error('Error loading processed reviews:', e);
    processedReviews = {};
}

// =================== MAIN LOAD ===================
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Admin Dashboard Loading...');
    
    // Check authentication
    const token = localStorage.getItem('userToken');
    const userRole = localStorage.getItem('userRole');
    
    // Debug auth
    console.log('Auth check - Token:', token ? 'Present' : 'Missing');
    console.log('User role:', userRole);
    
    if (!token || userRole !== 'admin') {
        console.warn('⚠️ Admin access required. Redirecting to login...');
        // Uncomment to enable redirect:
        // window.location.href = 'login.html';
        // return;
        
        // For testing, continue without redirect
        console.log('⚠️ Continuing in test mode (no redirect)');
    }
    
    // Show admin email
    try {
        if (token) {
            const payload = JSON.parse(atob(token.split('.')[1]));
            const adminEmail = document.getElementById('adminEmail');
            if (adminEmail) {
                adminEmail.textContent = payload.email || 'Admin';
            }
        }
    } catch {
        const adminEmail = document.getElementById('adminEmail');
        if (adminEmail) {
            adminEmail.textContent = 'Admin User';
        }
    }
    
    // Test connection first
    const isConnected = await testConnection();
    
    if (isConnected) {
        // Load dashboard
        await loadDashboard();
    } else {
        showConnectionError();
    }
    
    setupEventListeners();
});

// =================== CONNECTION TEST ===================
async function testConnection() {
    console.log('🔗 Testing backend connection...');
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/admin/test`);
        if (response.ok) {
            const data = await response.json();
            console.log('✅ Backend connected:', data.message);
            return true;
        }
    } catch (error) {
        console.error('❌ Backend connection failed:', error.message);
    }
    
    return false;
}

// =================== SMART FETCH FUNCTION ===================
async function fetchData(endpointType, params = {}) {
    const token = localStorage.getItem('userToken');
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    // Map endpoint types to your actual routes
    const endpointMap = {
        stats: '/api/admin/dashboard/stats',
        reviews: '/api/admin/reviews/flagged',
        reservations: '/api/admin/reservations',
        users: '/api/admin/users'
    };
    
    const endpoint = endpointMap[endpointType];
    
    if (!endpoint) {
        console.error(`Unknown endpoint type: ${endpointType}`);
        return { success: false, message: 'Invalid endpoint type' };
    }
    
    // Add query parameters
    let url = API_BASE_URL + endpoint;
    const queryParams = new URLSearchParams();
    
    if (endpointType === 'reservations' || endpointType === 'users') {
        queryParams.append('limit', params.limit || 5);
    }
    
    if (Object.keys(queryParams).length > 0) {
        url += '?' + queryParams.toString();
    }
    
    console.log(`🔄 Fetching: ${url}`);
    
    try {
        const response = await fetch(url, { headers });
        
        if (response.ok) {
            const data = await response.json();
            console.log(`✅ Success from ${endpointType}:`, data);
            return {
                success: true,
                data: data,
                endpoint: endpoint
            };
        } else {
            console.error(`❌ ${response.status} from ${endpointType}`);
            return {
                success: false,
                status: response.status,
                message: `HTTP ${response.status}`
            };
        }
    } catch (error) {
        console.error(`❌ Error fetching ${endpointType}:`, error.message);
        return {
            success: false,
            message: error.message
        };
    }
}

// =================== LOAD DASHBOARD ===================
async function loadDashboard() {
    showLoadingStates();
    
    try {
        console.log('🔄 Loading dashboard data...');
        
        // Fetch all data in parallel
        const [statsResult, reviewsResult, reservationsResult, usersResult] = await Promise.all([
            fetchData('stats'),
            fetchData('reviews'),
            fetchData('reservations', { limit: 5 }),
            fetchData('users', { limit: 5 })
        ]);
        
        console.log('📦 Data fetch results:', {
            stats: statsResult.success,
            reviews: reviewsResult.success,
            reservations: reservationsResult.success,
            users: usersResult.success
        });
        
        // 🔥 DEBUG: Log reviews data
        console.log('🔍 Reviews result:', reviewsResult);
        
        // Process and display data
        let anyDataLoaded = false;
        
        if (statsResult.success) {
            updateDashboard(statsResult.data.stats || statsResult.data);
            anyDataLoaded = true;
        }
        
        if (reviewsResult.success) {
            // 🔥 DEBUG: Check what we're passing
            console.log('🎯 Passing to displayFlaggedReviews:', {
                data: reviewsResult.data,
                reviews: reviewsResult.data.reviews,
                isArray: Array.isArray(reviewsResult.data.reviews)
            });
            
            displayFlaggedReviews(reviewsResult.data.reviews || reviewsResult.data);
            anyDataLoaded = true;
        } else {
            console.error('❌ Reviews fetch failed:', reviewsResult);
        }
        
        if (reservationsResult.success) {
            displayReservations(reservationsResult.data.reservations || reservationsResult.data);
            anyDataLoaded = true;
        }
        
        if (usersResult.success) {
            displayUsers(usersResult.data.users || usersResult.data);
            anyDataLoaded = true;
        }
        
        // Show notification
        if (anyDataLoaded) {
            showNotification('✅ Dashboard data loaded successfully', 'success');
        } else {
            showNotification('⚠️ Could not load dashboard data', 'warning');
        }
        
        // Display activity log
        displayRecentActivity();
        
    } catch (error) {
        console.error('❌ Dashboard load error:', error);
        showNotification('🚨 Error loading dashboard', 'error');
    } finally {
        hideLoadingStates();
    }
}

// =================== UPDATE DASHBOARD UI ===================
function updateDashboard(data) {
    console.log('🎨 Updating dashboard with:', data);
    
    // Update each statistic
    const updates = [
        { id: 'totalUsers', value: data.users?.total_users || 0 },
        { id: 'totalReviews', value: data.reviews?.total_reviews || 0 },
        { id: 'totalFlagged', value: data.reviews?.flagged_reviews || 0 },
        { id: 'totalDislikes', value: data.reviews?.total_dislikes || 0 },
        { id: 'totalReservations', value: data.reservations?.total_reservations || 0 },
        { id: 'avgRating', value: data.reviews?.avg_rating || 0 },
        { id: 'newUsersWeek', value: data.users?.new_users_week || 0 },
        { id: 'todayReservations', value: data.reservations?.today_reservations || 0 }
    ];
    
    updates.forEach(({ id, value }) => {
        const element = document.getElementById(id);
        if (element) {
            if (id === 'avgRating') {
                element.textContent = parseFloat(value).toFixed(1);
            } else {
                element.textContent = value;
            }
        }
    });
}

function displayFlaggedReviews(reviews) {
    console.log('=== 🚨 DISPLAY FLAGGED REVIEWS CALLED ===');
    console.log('Input reviews:', reviews);
    console.log('Type:', typeof reviews);
    try {
        processedReviews = JSON.parse(localStorage.getItem('processedReviews') || '{}');
    } catch (e) {
        console.error('Error loading processed reviews:', e);
    }
    
    const container = document.getElementById('flaggedReviewsList');
    const emptyState = document.getElementById('emptyState');
    const loadingState = document.getElementById('loadingState');
    
    console.log('Container:', container);
    console.log('Empty state:', emptyState);
    console.log('Loading state:', loadingState);
    
    if (!container) {
        console.error('❌ flaggedReviewsList container not found!');
        
        // Try to find or create container
        const possibleContainers = [
            'flaggedReviewsList',
            'flagged-reviews-list',
            'reviews-container',
            'flagged-reviews-container'
        ];
        
        for (const id of possibleContainers) {
            const el = document.getElementById(id);
            if (el) {
                console.log(`✅ Found alternative container: ${id}`);
                displayFlaggedReviewsInElement(el, reviews, processedReviews);
                return;
            }
        }
        
        // If still not found, create one
        const newDiv = document.createElement('div');
        newDiv.id = 'flaggedReviewsList';
        newDiv.style.border = '2px solid red';
        newDiv.style.padding = '20px';
        newDiv.innerHTML = '<h3>DEBUG: Flagged Reviews Container</h3>';
        document.body.appendChild(newDiv);
        console.log('✅ Created new container');
        
        displayFlaggedReviewsInElement(newDiv, reviews, processedReviews);
        return;
    }
    
    if (loadingState) loadingState.style.display = 'none';
    
    // Handle different input formats
    let reviewsArray = [];
    
    if (Array.isArray(reviews)) {
        reviewsArray = reviews;
    } else if (reviews && reviews.reviews && Array.isArray(reviews.reviews)) {
        reviewsArray = reviews.reviews;
    } else if (reviews && reviews.data && Array.isArray(reviews.data)) {
        reviewsArray = reviews.data;
    } else if (reviews && typeof reviews === 'object') {
        // Single review object
        reviewsArray = [reviews];
    }
    
    console.log(`📊 Reviews array ready: ${reviewsArray.length} items`);
    
    // Filter out processed reviews
    const activeReviews = reviewsArray.filter(review => {
        if (!review || !review.id) {
            console.log('Skipping review without ID:', review);
            return false;
        }
        
        const isProcessed = processedReviews[review.id];
        console.log(`Review ${review.id}: processed = ${isProcessed}`);
        
        return !isProcessed;
    });
    
    console.log(`✅ Active reviews after filter: ${activeReviews.length}`);
    
    if (activeReviews.length === 0) {
        console.log('No active reviews to display');
        if (emptyState) {
            emptyState.style.display = 'block';
            console.log('✅ Showing empty state');
        }
        container.innerHTML = '<p class="empty-message">No flagged reviews found</p>';
        updateFlaggedCount();
        return;
    }
    
    if (emptyState) emptyState.style.display = 'none';
    
    console.log(`🎨 Creating HTML for ${activeReviews.length} reviews`);
    
    // Clear container first
    container.innerHTML = '';
    
    activeReviews.forEach(review => {
        const daysAgo = Math.floor((new Date() - new Date(review.created_at)) / (1000 * 60 * 60 * 24)) || 0;
        const isCritical = (review.dislikes || 0) >= 5;
        const rating = review.rating || 0;
        const dislikes = review.dislikes || 0;
        const id = review.id;
        const comment = review.comment || 'No comment';
        const userName = review.user_name || review.userName || 'Anonymous';
        const userEmail = review.user_email || review.userEmail;
        
        console.log(`Creating card for review ${id}: "${comment.substring(0, 30)}..."`);
        
        const reviewCard = document.createElement('div');
        reviewCard.className = `review-card ${isCritical ? 'critical' : 'warning'}`;
        reviewCard.setAttribute('data-review-id', id);
        reviewCard.style.cssText = `
            border: 1px solid ${isCritical ? '#dc3545' : '#ffc107'};
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            background: ${isCritical ? '#f8d7da' : '#fff3cd'};
        `;
        
        reviewCard.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <h4 style="margin: 0; color: ${isCritical ? '#721c24' : '#856404'};">${userName}</h4>
                    ${userEmail ? `<p style="margin: 5px 0; color: #666;">${userEmail}</p>` : ''}
                    <p style="margin: 5px 0;"><strong>ID:</strong> ${id}</p>
                </div>
                <div style="text-align: right;">
                    <span style="background: ${isCritical ? '#dc3545' : '#ffc107'}; 
                          color: white; padding: 3px 8px; border-radius: 4px; font-size: 12px;">
                        ${isCritical ? '🚨 CRITICAL' : '⚠️ FLAGGED'}
                    </span>
                    <p style="margin: 5px 0; font-size: 12px;">${formatDate(review.created_at)}</p>
                </div>
            </div>
            
            <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 5px;">
                <p style="margin: 0;"><strong>Comment:</strong> ${escapeHtml(comment)}</p>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="margin-right: 15px;">⭐ ${rating}/5</span>
                    <span>👎 ${dislikes} dislikes</span>
                </div>
                <div>
                    <button onclick="approveReview(${id})" style="
                        padding: 8px 15px;
                        background: #28a745;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        margin-right: 10px;
                    ">
                        ✅ Approve
                    </button>
                    <button onclick="removeReview(${id})" style="
                        padding: 8px 15px;
                        background: #dc3545;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    ">
                        🗑️ Remove
                    </button>
                </div>
            </div>
            
            <div style="margin-top: 10px; font-size: 12px; color: #666;">
                ${daysAgo > 0 ? `Posted ${daysAgo} days ago` : 'Posted today'}
            </div>
        `;
        
        container.appendChild(reviewCard);
    });
    
    console.log(`✅ Created ${container.children.length} review cards`);
    updateFlaggedCount();
}

// Helper function for alternative containers
function displayFlaggedReviewsInElement(container, reviews, processedReviews) {
    console.log('Using alternative container display');
    
    // Simplified display
    const reviewsArray = Array.isArray(reviews) ? reviews : (reviews?.reviews || []);
    
    if (reviewsArray.length === 0) {
        container.innerHTML = '<p>No flagged reviews</p>';
        return;
    }
    
    container.innerHTML = reviewsArray.map(review => `
        <div style="border: 2px solid orange; padding: 10px; margin: 10px;">
            <h4>Review #${review.id}</h4>
            <p><strong>Dislikes:</strong> ${review.dislikes}</p>
            <p>${review.comment?.substring(0, 50)}...</p>
            <button onclick="approveReview(${review.id})">Approve</button>
        </div>
    `).join('');
}

function displayReservations(reservations) {
    const container = document.getElementById('reservationsList');
    const emptyState = document.getElementById('reservationsEmpty');
    const loadingState = document.getElementById('reservationsLoading');
    
    if (!container) return;
    
    if (loadingState) loadingState.style.display = 'none';
    
    const reservationsArray = Array.isArray(reservations) ? reservations : [];
    
    if (reservationsArray.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        container.innerHTML = '';
        return;
    }
    
    if (emptyState) emptyState.style.display = 'none';
    
    container.innerHTML = reservationsArray.map(res => {
        if (!res) return '';
        
        const today = new Date().toISOString().split('T')[0];
        const resDate = res.res_date || today;
        const status = resDate === today ? 'today' : 
                      new Date(resDate) < new Date(today) ? 'past' : 'upcoming';
        
        return `
            <div class="reservation-card ${status}">
                <div class="reservation-header">
                    <div class="customer-info">
                        <strong>${escapeHtml(res.name || 'No Name')}</strong>
                        <div class="customer-email">${escapeHtml(res.email || 'No email')}</div>
                    </div>
                    <span class="status-badge ${status}">${status.toUpperCase()}</span>
                </div>
                
                <div class="reservation-details">
                    <div><i class="fas fa-calendar"></i> ${resDate}</div>
                    <div><i class="fas fa-clock"></i> ${res.res_time || '--:--'}</div>
                    <div><i class="fas fa-users"></i> ${res.people || 0} people</div>
                    ${res.user_email ? `<div><i class="fas fa-user"></i> ${escapeHtml(res.user_email)}</div>` : ''}
                </div>
            </div>
        `;
    }).join('');
}

function displayUsers(users) {
    const container = document.getElementById('usersList');
    const loadingState = document.getElementById('usersLoading');
    
    if (!container) return;
    
    if (loadingState) loadingState.style.display = 'none';
    
    const usersArray = Array.isArray(users) ? users : [];
    
    if (usersArray.length === 0) {
        container.innerHTML = '<p class="empty-text">No users found</p>';
        return;
    }
    
    container.innerHTML = usersArray.map(user => {
        if (!user) return '';
        
        return `
            <div class="user-card">
                <div class="user-avatar">
                    <i class="fas fa-user-circle"></i>
                </div>
                <div class="user-info">
                    <strong>${escapeHtml(user.name || 'No Name')}</strong>
                    <div class="user-email">${escapeHtml(user.email || 'No email')}</div>
                    
                    <div class="user-meta">
                        <span class="join-date">Joined: ${formatDate(user.created_at)}</span>
                    </div>
                    
                    <div class="user-stats">
                        <span><i class="fas fa-star"></i> ${user.review_count || 0} reviews</span>
                        <span><i class="fas fa-calendar"></i> ${user.reservation_count || 0} reservations</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// =================== REVIEW ACTIONS (YOUR BACKEND INTEGRATION) ===================
async function approveReview(id) {
    if (!confirm('Approve this review? This will reset dislikes to 0.')) {
        return;
    }
    
    try {
        const token = localStorage.getItem('userToken');
        const url = `${API_BASE_URL}/api/admin/reviews/${id}/approve`;
        
        console.log(`🔄 Approving review ${id} via PUT ${url}`);
        
        const response = await fetch(url, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            // Mark as processed in localStorage
            processedReviews[id] = {
                action: 'approved',
                date: new Date().toISOString()
            };
            localStorage.setItem('processedReviews', JSON.stringify(processedReviews));
            
            // Remove from UI
            removeReviewFromUI(id);
            
            showNotification(`✅ Review #${id} approved successfully`, 'success');
            
            // Refresh flagged reviews list after 1 second
            setTimeout(() => {
                loadFlaggedReviews();
            }, 1000);
            
        } else {
            throw new Error(result.message || 'Failed to approve review');
        }
        
    } catch (error) {
        console.error('❌ Approve error:', error);
        showNotification(`❌ Failed to approve review: ${error.message}`, 'error');
    }
}

async function removeReview(id) {
    if (!confirm('Permanently delete this review?')) {
        return;
    }
    
    try {
        const token = localStorage.getItem('userToken');
        const url = `${API_BASE_URL}/api/admin/reviews/${id}`;
        
        console.log(`🔄 Deleting review ${id} via DELETE ${url}`);
        
        const response = await fetch(url, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            // Mark as processed in localStorage
            processedReviews[id] = {
                action: 'deleted',
                date: new Date().toISOString()
            };
            localStorage.setItem('processedReviews', JSON.stringify(processedReviews));
            
            // Remove from UI
            removeReviewFromUI(id);
            
            showNotification(`✅ Review #${id} deleted successfully`, 'success');
            
            // Refresh flagged reviews list after 1 second
            setTimeout(() => {
                loadFlaggedReviews();
            }, 1000);
            
        } else {
            throw new Error(result.message || 'Failed to delete review');
        }
        
    } catch (error) {
        console.error('❌ Delete error:', error);
        showNotification(`❌ Failed to delete review: ${error.message}`, 'error');
    }
}

// =================== HELPER FUNCTIONS ===================
function removeReviewFromUI(id) {
    const card = document.querySelector(`[data-review-id="${id}"]`);
    if (card) {
        card.style.transition = 'all 0.3s';
        card.style.opacity = '0';
        card.style.transform = 'translateX(-20px)';
        
        setTimeout(() => {
            if (card.parentNode) {
                card.remove();
                updateFlaggedCount();
                checkEmptyState();
            }
        }, 300);
    }
}

async function loadFlaggedReviews() {
    try {
        const result = await fetchData('reviews');
        if (result.success) {
            displayFlaggedReviews(result.data.reviews || result.data);
        }
    } catch (error) {
        console.error('Error refreshing reviews:', error);
    }
}

function updateFlaggedCount() {
    const container = document.getElementById('flaggedReviewsList');
    const flaggedElement = document.getElementById('totalFlagged');
    
    if (container && flaggedElement) {
        const count = container.querySelectorAll('.review-card').length;
        flaggedElement.textContent = count;
    }
}

function checkEmptyState() {
    const container = document.getElementById('flaggedReviewsList');
    const emptyState = document.getElementById('emptyState');
    
    if (container && emptyState) {
        emptyState.style.display = container.children.length === 0 ? 'block' : 'none';
    }
}

function showConnectionError() {
    const container = document.getElementById('dashboard-content');
    if (container) {
        container.innerHTML = `
            <div style="text-align: center; padding: 40px; background: #f8d7da; border-radius: 10px; margin: 20px;">
                <h3 style="color: #721c24;">⚠️ Backend Connection Failed</h3>
                <p>Cannot connect to backend server at: <code>${API_BASE_URL}</code></p>
                <p>Please ensure:</p>
                <ul style="text-align: left; display: inline-block;">
                    <li>Backend server is running (<code>node index.js</code> or <code>npm start</code>)</li>
                    <li>Server is on port 3000</li>
                    <li>Check browser console (F12) for errors</li>
                    <li>Verify CORS settings in backend</li>
                </ul>
                <br>
                <button onclick="location.reload()" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 10px;">
                    🔄 Retry Connection
                </button>
                <button onclick="testBackendManually()" style="padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 10px;">
                    🧪 Test Backend
                </button>
            </div>
        `;
    }
}

// =================== UTILITY FUNCTIONS ===================
function showLoadingStates() {
    const elements = ['loadingState', 'reservationsLoading', 'usersLoading'];
    elements.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'block';
    });
}

function hideLoadingStates() {
    const elements = ['loadingState', 'reservationsLoading', 'usersLoading'];
    elements.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    try {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    } catch {
        return 'Invalid date';
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function displayRecentActivity() {
    const activityDiv = document.getElementById('activityLogContent');
    if (!activityDiv) return;
    
    const now = new Date();
    const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    const dateString = now.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
    });
    
    const totalFlagged = document.getElementById('totalFlagged')?.textContent || 0;
    const totalUsers = document.getElementById('totalUsers')?.textContent || 0;
    
    activityDiv.innerHTML = `
        <div class="log-item success">
            <div class="log-icon">
                <i class="fas fa-server"></i>
            </div>
            <div class="log-content">
                <div class="log-title">Backend Connected</div>
                <div class="log-meta">
                    <span class="log-time">${timeString}</span>
                    <span>Server: ${API_BASE_URL}</span>
                </div>
            </div>
        </div>
        
        <div class="log-item info">
            <div class="log-icon">
                <i class="fas fa-database"></i>
            </div>
            <div class="log-content">
                <div class="log-title">Dashboard Loaded</div>
                <div class="log-meta">
                    <span class="log-time">${timeString}</span>
                    <span>Users: ${totalUsers} • Flagged: ${totalFlagged}</span>
                </div>
            </div>
        </div>
        
        <div class="log-item ${totalFlagged > 0 ? 'warning' : 'success'}">
            <div class="log-icon">
                <i class="fas fa-flag"></i>
            </div>
            <div class="log-content">
                <div class="log-title">${totalFlagged > 0 ? 'Flagged Reviews Found' : 'All Clear'}</div>
                <div class="log-meta">
                    <span class="log-time">${timeString}</span>
                    <span>${totalFlagged} reviews need attention</span>
                </div>
            </div>
        </div>
        
        <div class="log-item info">
            <div class="log-icon">
                <i class="fas fa-sync-alt"></i>
            </div>
            <div class="log-content">
                <div class="log-title">Last Updated</div>
                <div class="log-meta">
                    <span class="log-time">${timeString}</span>
                    <span>${dateString}</span>
                </div>
            </div>
        </div>
    `;
}

// =================== EVENT LISTENERS ===================
function setupEventListeners() {
    // Logout button
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
        if (confirm('Are you sure you want to logout?')) {
            localStorage.clear();
            window.location.href = 'index.html';
        }
    });
    
    // Refresh button
    document.getElementById('refreshBtn')?.addEventListener('click', async () => {
        const btn = document.getElementById('refreshBtn');
        if (btn) {
            const originalHtml = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
            btn.disabled = true;
            
            await loadDashboard();
            
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        }
    });
}

// =================== NOTIFICATION SYSTEM ===================
function showNotification(message, type = 'info') {
    // Remove existing notifications
    document.querySelectorAll('.custom-notification').forEach(n => n.remove());
    
    const notification = document.createElement('div');
    notification.className = `custom-notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#d4edda' : 
                    type === 'error' ? '#f8d7da' : 
                    type === 'warning' ? '#fff3cd' : '#d1ecf1'};
        color: ${type === 'success' ? '#155724' : 
                type === 'error' ? '#721c24' : 
                type === 'warning' ? '#856404' : '#0c5460'};
        border: 1px solid ${type === 'success' ? '#c3e6cb' : 
                          type === 'error' ? '#f5c6cb' : 
                          type === 'warning' ? '#ffeeba' : '#bee5eb'};
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideIn 0.3s ease;
        max-width: 400px;
    `;
    
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                         type === 'error' ? 'exclamation-circle' : 
                         type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        <span style="flex: 1;">${message}</span>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; cursor: pointer; color: inherit; margin-left: 10px;">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Add CSS animations
if (!document.querySelector('#custom-notification-styles')) {
    const style = document.createElement('style');
    style.id = 'custom-notification-styles';
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}

// =================== DEBUG FUNCTIONS ===================
async function testBackendManually() {
    console.log('🧪 Testing backend endpoints manually...');
    
    const endpoints = [
        `${API_BASE_URL}/api/admin/test`,
        `${API_BASE_URL}/api/admin/dashboard/stats`,
        `${API_BASE_URL}/api/admin/reviews/flagged`
    ];
    
    for (const url of endpoints) {
        try {
            const response = await fetch(url);
            console.log(`${response.ok ? '✅' : '❌'} ${url}: ${response.status}`);
            
            if (response.ok) {
                const data = await response.json();
                console.log('Response:', data);
            }
        } catch (error) {
            console.log(`❌ ${url}: ${error.message}`);
        }
    }
}

// =================== GLOBAL FUNCTIONS ===================
window.approveReview = approveReview;
window.removeReview = removeReview;
window.testBackendManually = testBackendManually;
window.loadDashboard = loadDashboard;

console.log('✅ Admin dashboard script loaded!');